package com.example.ArticlePublishingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArticlePublishingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
