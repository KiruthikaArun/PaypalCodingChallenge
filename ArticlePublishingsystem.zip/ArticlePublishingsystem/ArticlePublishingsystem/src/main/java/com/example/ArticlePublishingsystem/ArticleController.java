package com.example.ArticlePublishingsystem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/Articles")
public class ArticleController {

  @Autowired
  private ArticleRepository articleRepository;

  @Autowired
  private FavouriteRepository favouriteRepository;

  /*
  API Set 1:
  1. API to create an article with the title, article content and author name.
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/
  */
  @RequestMapping(method = RequestMethod.POST, consumes = "application/json")
  public Article CreateArticle(@RequestBody Article article) {
    Article saveArticle = articleRepository.saveAndFlush(article);
    return saveArticle;
  }

  /*
  API Set 1:
  2. API to list the articles (active version) which are ordered by number of votes in descending order.
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/getActiveArticlesByVote
  */
  @GetMapping(value = "/getActiveArticlesByVote")
  public List<Article> getActiveArticlesByVote() {
    List<Article> article = articleRepository.findAll().stream().filter(x -> "yes".equals(x.getActive())).sorted(Comparator.comparing(Article::getVote).reversed()).collect(Collectors.toList());
    return article;
  }

  /*API Set 1:
   3. API to update an existing article with new version, i,e whenever an edit is made to an article a new version should
  be created and will be set as the active article to be served
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/updateArticle/2
  */
  @PutMapping(value = "/updateArticle/{id}")
  public Article updateArticle(@RequestBody Article article,@PathVariable long id) {
    Optional<Article> optional = articleRepository.findById(id);
    if(!optional.isPresent())
      return null;
    Article origArticle = optional.get();
    origArticle.setActive("no");
    articleRepository.saveAndFlush(origArticle);
    Article newArticle = new Article();
    if(article.getVote() != 0)
      newArticle.setVote(article.getVote());
    if(article.getContent() != null)
      newArticle.setContent(article.getContent());
    if(article.getName() != null)
      newArticle.setName(article.getName());
    if(article.getTitle() != null)
      newArticle.setTitle(article.getTitle());
    newArticle.setActive("yes");
    articleRepository.saveAndFlush(newArticle);
    return newArticle;
  }

  /*
  API Set 1:
  4. API to UP/DOWN vote the existing article and add to their Favourites for Future reference.
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/vote/1?vote=false
   */
  @PutMapping(value = "/vote/{id}")
  public void votebyArticleId(@PathVariable("id") long id, @RequestParam boolean vote) {
    Optional<Article> article = articleRepository.findById(id);
    Article a = article.get();
    long currentVote = a.getVote();

    if(vote)
      currentVote++;
    else
      currentVote--;
      a.setVote(currentVote);
      articleRepository.saveAndFlush(a);
      Favourite fav = new Favourite(a);
      favouriteRepository.save(fav);
  }

  /*
  API Set 1:
  4.Get the  Favourites already added for Future reference.
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/getAllFavourites
   */
  @GetMapping(value = "/getAllFavourites")
  public List<Favourite> getAllFavourites() {
    return  favouriteRepository.findAll();
  }

  /*
  API to list all existing Articles
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/getArticles
   */
  @GetMapping("/getArticles")
  public List<Article> getArticles() {
    return articleRepository.findAll();
  }

  /*
  API to list Article by Id
  Example URI - http://localhost:7070/paypal/Articleapp/Articles/4
   */
  @GetMapping(value = "/{id}")
  public Article getArticlebyId(@PathVariable long id) {
    Optional<Article> article = articleRepository.findById(id);
    return article.get();
  }


}
