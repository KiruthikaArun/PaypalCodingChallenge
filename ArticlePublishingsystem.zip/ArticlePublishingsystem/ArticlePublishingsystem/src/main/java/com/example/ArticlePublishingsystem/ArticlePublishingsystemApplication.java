package com.example.ArticlePublishingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArticlePublishingsystemApplication {

	public static void main(String[] args) {

		SpringApplication.run(ArticlePublishingsystemApplication.class, args);
	}

}
