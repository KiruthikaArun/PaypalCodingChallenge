package com.example.ArticlePublishingsystem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@Entity
@Table(name = "Article", schema = "PUBLIC")
@XmlRootElement
public class Article {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;
  private String Title;
  private String Active;
  private String Content;
  private String Name;
  private long Vote;



  Article()  { }

  @Column(name = "Title")
  public String getTitle() {
    return Title;
  }

  public void setTitle(String Title) {
    this.Title = Title;
  }

   @Column(name = "Active")
   public String getActive() {
     return Active;
   }

  public void setActive(String Active) {
    this.Active = Active;
  }

  @Column(name = "Content")
  public String getContent() {
    return Content;
  }

  public void setContent(String Content) {
    this.Content = Content;
  }

  @Column(name = "Name")
  public String getName() {
    return Name;
  }

  public void setName(String Name) {
    this.Name = Name;
  }

  @Column(name = "Vote")
  public long getVote() {
    return Vote;
  }

  public void setVote(long Vote) {
    this.Vote = Vote;
  }

  public boolean equals(Object obj) {
    if(obj == null)
      return false;
    if(!(obj instanceof  Article))
      return false;

    Article a = (Article) obj;
    if(this.getActive() != a.getActive())
      return false;
    return true;
    }

  @Override
  public int hashCode() {
    return Objects.hash(Title);
  }
}
