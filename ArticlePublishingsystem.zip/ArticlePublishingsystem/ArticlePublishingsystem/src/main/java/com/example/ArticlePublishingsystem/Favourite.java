package com.example.ArticlePublishingsystem;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Favourite", schema = "PUBLIC")
public class Favourite {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @OneToOne()
  @JoinColumn(name = "ARTICLE_ID", updatable = false, nullable = false)
  private Article article;

  public Favourite() {  }

  public Favourite(Article article) {
    this.setArticle(article);
  }

  public Article getArticle() {
    return article;
  }
  public void setArticle(Article article) {
    this.article = article;
  }

}
